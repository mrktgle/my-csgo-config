Thanks for downloading vibranceGUI!

----------------------------------------------------------------------------------------------------

H1Z1 can not be detected -- how can I fix this? 
- 1) Press "Add manually"
- 2) Locate your H1Z1 installation folder
- 3) Locate the .exe file of the actual H1Z1 game (not the H1Z1 launcher .exe!)

----------------------------------------------------------------------------------------------------

For Help, Troubleshooting and Q&A see the Steam Guide: https://vibrancegui.com/vibrance/guide 
If the Guide did not help you to fix your problem, contact me on Twitter: https://twitter.com/juvlarN